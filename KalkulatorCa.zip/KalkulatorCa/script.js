let display = document.getElementById("display");

function appendValue(value) {
    display.value += value;
}

function clearDisplay() {
    display.value = "";
}

function deleteLast() {
    display.value = display.value.slice(0, -1);
}

function processInput() {
    let text = display.value.toLowerCase();

    // Ambil semua angka dari kalimat
    let numbers = text.match(/\d+/g);

    if (!numbers) {
        display.value = "Tidak ada angka";
        return;
    }

    numbers = numbers.map(Number);

    let result = numbers[0];

    // NLP SOAL CERITA
    for (let i = 1; i < numbers.length; i++) {

        if (
            text.includes("tambah") ||
            text.includes("lagi") ||
            text.includes("membeli") ||
            text.includes("dapat") ||
            text.includes("ditambah")
        ) {
            result += numbers[i];
        } 
        else if (
            text.includes("kurang") ||
            text.includes("dimakan") ||
            text.includes("hilang") ||
            text.includes("diambil") ||
            text.includes("berkurang")
        ) {
            result -= numbers[i];
        } 
        else if (
            text.includes("kali") ||
            text.includes("masing") ||
            text.includes("setiap") ||
            text.includes("setiapnya")
        ) {
            result *= numbers[i];
        } 
        else if (
            text.includes("bagi") ||
            text.includes("dibagi")
        ) {
            result /= numbers[i];
        }
    }

    display.value = result;
}